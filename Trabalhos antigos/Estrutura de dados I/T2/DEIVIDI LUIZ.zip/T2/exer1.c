/*1)Implemente um programa, para alocar memória para um 
vetor. O número de posições do vetor será indicado via 
teclado, assim como o conteúdo das posições. Após a 
atribuição de valores às posições do vetor, o programa 
deve imprimir(na tela) as posições e seus conteúdos.*/

#include <stdio.h>
#include <stdlib.h>


int main(){
	int tamanho;

	printf("Informe o tamanho do vetor: ");
	scanf("%d", &tamanho);

	int *p = (int *)malloc(sizeof(tamanho));

	if(p){ //testa se memória foi alocada
		printf("Memória alocada com sucesso.\n");
	}else{
		printf("Não foi possivel alocar a memória.\n");
		return 0; //finaliza o programa
	}

	for(int i = 0; i<tamanho; i++){
		printf("Digite: ");
		scanf("%d", (p+i));
	}

	printf("\n");
	
	for(int i = 0; i<tamanho; i++){
		printf("Posicao: %d - Valor: %d\n", i, *(p+i));
	}

	free(p);
	return 0;
}