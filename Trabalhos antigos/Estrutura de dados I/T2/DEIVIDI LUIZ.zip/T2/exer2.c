/*2) Altere o programa para armazenar uma estrutura em 
cada posição do vetor.*/

#include <stdio.h>
#include <stdlib.h>

int main(){
	typedef struct{
		char nome[50];
		char endereco[100];
		int matricula;
	}estudante;


	printf("Informe a quantidade de estudantes: ");
	int tamanho = 0;

	scanf("%d", &tamanho);
	
	int ax = 0;

	estudante *e = (estudante*)(malloc(sizeof(estudante)*tamanho));
	
	if(e){ //testa se memória foi alocada
		printf("Memória alocada com sucesso.\n\n");
	}else{
		printf("Não foi possivel alocar a memória.\n");
		return 0; //finaliza o programa
	}

	fflush(stdin);

	for(int i = 0; i<tamanho; i++){
		getchar();
		printf("Nome do aluno: ");
		fgets((e+i)->nome, 50, stdin);
		printf("Endereco: ");
		fgets((e+i)->endereco, 100, stdin);
		printf("Matricula: ");
		scanf("%d", &ax);
		(e+i)->matricula = ax;
		printf("\n");
	}

	for(int i = 0; i<tamanho; i++){
		printf("Nome do aluno: %s", (e+i)->nome);
		printf("Endereco: %s", (e+i)->endereco);
		printf("Matricula: %d", (e+i)->matricula);
		printf("\n\n");
	}

	free(e);
	return 0;
}