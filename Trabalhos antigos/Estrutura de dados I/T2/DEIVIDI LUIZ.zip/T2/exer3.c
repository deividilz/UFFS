/*Altere o programa do exercício 1, de forma que receba números inteiros do usuário
indefinidamente. O programa finaliza quando o usuário entrar com o número 0.
a) Aloque, inicialmente, memória para 5 inteiros;
b) Caso o usuário entrar com mais inteiros, faça a realocação, alocando espaço para mais 5
inteiros e assim sucessivamente;*/

#include <stdio.h>
#include <stdlib.h>


int main(){
	int tamanho = 5;
	int i = -1;

	int * p = (int *)calloc(tamanho, sizeof(int));

	do{
		i++;
		printf("Digite: ");
		scanf("%d", (p+i));
		if((i+1)>=tamanho){
			tamanho = tamanho + 5;
			int *pNew = realloc(p, tamanho * sizeof(int));
			p = pNew;

			if(pNew){ //testa se memória foi alocada
				printf("Memória alocada com sucesso. Tamanho: %d\n", tamanho);
			}else{
				printf("Não foi possivel alocar a memória.\n");
				return 0; //finaliza o programa
			}
		}
	}while(*(p+i)!=0);
	
	printf("\n");

	i = -1;
	do{
		i++;
		printf("Posicao: %d - Valor: %d\n", i, *(p+i));
	}while(*(p+i)!=0);

	free(p);

	return 0;
}