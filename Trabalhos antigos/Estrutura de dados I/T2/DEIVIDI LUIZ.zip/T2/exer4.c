/*Crie uma função que receba como parâmetros dois vetores de inteiros, v1 e v2, e as suas
respectivas quantidades de elementos, n1 e n2. A função deverá retornar um ponteiro para
um terceiro vetor, v3, com capacidade para (n1 + n2) elementos, alocado dinamicamente,
contendo a união de v1 e v2.

Por exemplo, se v1 = {11, 13, 45, 7} e v2 = {24, 4, 16, 81, 10, 12}, v3 irá conter {11, 13,
45, 7, 24, 4, 16, 81, 10, 12}.
O cabeçalho dessa função deverá ser o seguinte:
int* uniao(int *v1, int n1, int *v2, int n2);

Em seguida, crie a função principal do programa para chamar a função união passando dois
vetores informados pelo usuário (ou declarados estaticamente). Em seguida, o programa
deve exibir na tela os elementos do vetor resultante. Não esqueça de liberar a memória
alocada dinamicamente.*/


#include <stdio.h>
#include <stdlib.h>

int* uniao(int *v1, int n1, int *v2, int n2){
	int * v3 = (int *)calloc((n1+n2), sizeof(int));
	if(v3){ //testa se memória foi alocada
		printf("Memória alocada com sucesso.\n");
	}else{
		printf("Não foi possivel alocar a memória.\n");
		return 0; //finaliza o programa
	}

	int i = -1;
	int ax = 0;

	v3 = v1;

	do{
		i++;
	}while(*(v3+i)!=0);
	
	while(*(v2+ax)!=0){
		*(v3+i) = *(v2+ax);
		i++;
		ax++;
	}

	return v3;
}

int main(){
	int i = 0;
	int ax, ax2;
	int tamanho1=0, tamanho2=0;

	printf("Informe o tamanho do vetor 1: \n");
	scanf("%d", &tamanho1);
	printf("Informe o tamanho do vetor 2: \n");
	scanf("%d", &tamanho2);
	
	int * v1 = (int *)calloc(tamanho1, sizeof(int));
	int * v2 = (int *)calloc(tamanho2, sizeof(int));
	

	printf("Vetor 1!\n");
	for(int i = 0; i<tamanho1; i++){
		printf("Digite: ");
		scanf("%d", (v1+i));
	}

	printf("Vetor 2!\n");
	for(int i = 0; i<tamanho2; i++){
		printf("Digite: ");
		scanf("%d", (v2+i));

	};

	int *p = uniao(v1, tamanho1, v2, tamanho2);

	for(int i2=0; i2<(tamanho1+tamanho2); i2++){
		printf("Posicao: %d - Valor: %d\n", i2, *(p+i2));
	}
	free(v1);
	free(v2);

	return 0;
}